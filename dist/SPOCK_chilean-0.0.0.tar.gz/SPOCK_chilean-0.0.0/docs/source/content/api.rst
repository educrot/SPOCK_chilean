***
API
***

The SPOCK\_chilean API reference
==================================

.. automodule:: SPOCK_chilean
   :members:

Make night plans
------------------

.. automodule:: SPOCK_chilean.make_night_plans
   :members:

Text files
------------------

.. automodule:: SPOCK_chilean.txt_files
   :members:

ETC
------------------

.. automodule:: SPOCK_chilean.ETC
   :members:

