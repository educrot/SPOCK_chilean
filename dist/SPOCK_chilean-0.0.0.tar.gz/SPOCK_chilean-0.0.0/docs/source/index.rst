SPOCK chilean nights 
=====================

The project SPECULOOS -Search for habitable Planets EClipsing ULtra-cOOl Stars –
searches for potentially habitable exoplanets around the smallest and coolest stars
of the solar neighborhood `Link to site <https://www.speculoos.uliege.be/cms/c_4259452/fr/speculoos>`_.


.. toctree::
   :maxdepth: 2
   :caption: Content
   :hidden:

   content/api
   content/quick-ref
   content/installation

.. toctree::
   :caption: Quick start
   :maxdepth: 2

   examples/SPOCK_chilean/pythontuto.rst
   examples/SPOCK_chilean/exampleapp.rst



