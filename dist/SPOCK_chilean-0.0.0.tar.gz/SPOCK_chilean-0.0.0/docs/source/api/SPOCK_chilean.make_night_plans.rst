SPOCK\_chilean.make\_night\_plans
===========================

.. automodule:: SPOCK_chilean.make_night_plans
    :members:
